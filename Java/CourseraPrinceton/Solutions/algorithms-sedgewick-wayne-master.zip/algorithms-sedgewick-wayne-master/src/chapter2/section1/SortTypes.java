package chapter2.section1;

/**
 * Created by Rene Argento on 05/02/17.
 */
public enum SortTypes {

    SELECTION, INSERTION, SHELL;

}
